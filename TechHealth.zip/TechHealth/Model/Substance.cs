﻿namespace TechHealth.Model
{
    public class Substance
    {
        public string SubstanceId { get; set; }
        public string SubstanceName { get; set; }
    }
}