﻿namespace TechHealth.Model
{
    public class EmlpoymentData
    {
        public string Our { get; set; }
        public string Profession { get; set; }
        public string Workplace { get; set; }
        public string Job { get; set; }
    }
}