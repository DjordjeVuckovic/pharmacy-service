﻿namespace TechHealth.Model
{
    public enum MedicineStatus
    {
        Waiting,
        Approved,
        Rejected,
    }
}