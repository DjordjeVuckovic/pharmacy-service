﻿namespace TechHealth.Model
{
    public enum VacationStatus
    {
        Waiting,
        Approved,
        Rejected,
    }
}