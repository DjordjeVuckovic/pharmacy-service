// File:    Secretary.cs
// Author:  djord
// Created: Monday, March 28, 2022 8:47:45 AM
// Purpose: Definition of Class Secretary

using System;

namespace TechHealth.Model
{
   public class Secretary : Person
   {
   }
}