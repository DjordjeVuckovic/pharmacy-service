// File:    Gender.cs
// Author:  djord
// Created: Monday, March 28, 2022 9:59:11 AM
// Purpose: Definition of Enum Gender

using System;

namespace TechHealth.Model
{
   public enum Gender
   {
      Male,
      Female,
      None
   }
}