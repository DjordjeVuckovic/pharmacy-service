// File:    AppointmentType.cs
// Author:  nsred
// Created: Thursday, April 7, 2022 6:05:27 PM
// Purpose: Definition of Enum AppointmentType

using System;

namespace TechHealth.Model
{
   public enum AppointmentType
   {
      examination=0,
      operation=1
   }
   
}