// File:    Manager.cs
// Author:  djord
// Created: Monday, March 28, 2022 8:47:45 AM
// Purpose: Definition of Class Manager

using System;

namespace TechHealth.Model
{
   public class Manager : Person
   {
   }
}