﻿using System;
using TechHealth.Model;

namespace TechHealth.Service.IService
{
    public interface IReferralRequestService:IService<ReferralRequest,String>
    {
        
    }
}