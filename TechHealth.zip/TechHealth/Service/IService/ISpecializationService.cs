﻿using TechHealth.Model;

namespace TechHealth.Service.IService
{
    public interface ISpecializationService:IService<Specialization,int>
    {
        
    }
}