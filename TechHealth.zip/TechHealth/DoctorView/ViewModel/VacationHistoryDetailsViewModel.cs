﻿using TechHealth.Core;

namespace TechHealth.DoctorView.ViewModel
{
    public class VacationHistoryDetailsViewModel:ViewModelBase
    {
        
    }
}