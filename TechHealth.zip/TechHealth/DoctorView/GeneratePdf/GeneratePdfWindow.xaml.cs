﻿using System.Windows;

namespace TechHealth.DoctorView.GeneratePdf
{
    public partial class GeneratePdfWindow : Window
    {
        public GeneratePdfWindow()
        {
            InitializeComponent();
        }
    }
}