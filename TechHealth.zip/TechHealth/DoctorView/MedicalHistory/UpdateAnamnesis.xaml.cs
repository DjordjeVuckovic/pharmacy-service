﻿using System.Windows;

namespace TechHealth.DoctorView.MedicalHistory
{
    public partial class UpdateAnamnesis : Window
    {
        public UpdateAnamnesis()
        {
            InitializeComponent();
        }
    }
}