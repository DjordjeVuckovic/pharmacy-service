﻿using System.Windows.Controls;

namespace TechHealth.DoctorView.View
{
    public partial class AccountView : UserControl
    {
        public AccountView()
        {
            InitializeComponent();
        }
    }
}