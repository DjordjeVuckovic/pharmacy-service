﻿using System.Windows.Controls;

namespace TechHealth.DoctorView.View
{
    public partial class MedicineDetailsView : UserControl
    {
        public MedicineDetailsView()
        {
            InitializeComponent();
        }
    }
}