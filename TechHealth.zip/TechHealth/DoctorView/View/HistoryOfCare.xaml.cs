﻿using System.Windows.Controls;

namespace TechHealth.DoctorView.View
{
    public partial class HistoryOfCare : UserControl
    {
        public HistoryOfCare()
        {
            InitializeComponent();
        }
    }
}