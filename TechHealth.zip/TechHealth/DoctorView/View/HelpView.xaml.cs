﻿using System.Windows.Controls;

namespace TechHealth.DoctorView.View
{
    public partial class HelpView : UserControl
    {
        public HelpView()
        {
            InitializeComponent();
        }
    }
}