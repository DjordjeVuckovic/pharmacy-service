﻿using System.Windows.Controls;

namespace TechHealth.DoctorView.View
{
    public partial class VactionHistoryView : UserControl
    {
        public VactionHistoryView()
        {
            InitializeComponent();
        }
    }
}