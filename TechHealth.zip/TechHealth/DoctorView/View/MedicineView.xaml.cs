﻿using System.Windows.Controls;
using TechHealth.DoctorView.ViewModel;

namespace TechHealth.DoctorView.View
{
    public partial class MedicineView : UserControl
    {
        public MedicineView()
        {
            InitializeComponent();
        }
    }
}