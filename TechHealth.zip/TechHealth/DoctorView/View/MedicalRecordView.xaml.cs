﻿using System.Windows.Controls;

namespace TechHealth.DoctorView.View
{
    public partial class MedicalRecordView : UserControl
    {
        public MedicalRecordView()
        {
            InitializeComponent();
        }
    }
}