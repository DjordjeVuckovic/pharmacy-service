﻿using System.Windows;

namespace TechHealth.DoctorView.CRUDAppointments
{
    public partial class UpdateAppointment : Window
    {
        public UpdateAppointment()
        {
            InitializeComponent();
        }
    }
}