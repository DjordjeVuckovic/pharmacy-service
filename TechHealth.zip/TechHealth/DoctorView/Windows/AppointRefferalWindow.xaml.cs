﻿using System.Windows;

namespace TechHealth.DoctorView.Windows
{
    public partial class AppointRefferalWindow : Window
    {
        public AppointRefferalWindow()
        {
            InitializeComponent();
        }
    }
}