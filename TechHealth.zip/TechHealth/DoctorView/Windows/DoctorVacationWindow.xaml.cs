﻿using System.Windows;

namespace TechHealth.DoctorView.Windows
{
    public partial class DoctorVacationWindow : Window
    {
        public DoctorVacationWindow()
        {
            InitializeComponent();
        }
    }
}