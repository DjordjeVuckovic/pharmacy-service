﻿using System.Windows;

namespace TechHealth.DoctorView.Windows
{
    public partial class ReferralWindow : Window
    {
        public ReferralWindow()
        {
            InitializeComponent();
        }
    }
}