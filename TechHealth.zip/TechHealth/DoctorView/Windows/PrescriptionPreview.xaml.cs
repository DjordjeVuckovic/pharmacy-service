﻿using System.Windows;

namespace TechHealth.DoctorView.Windows
{
    public partial class PrescriptionPreview : Window
    {
        public PrescriptionPreview()
        {
            InitializeComponent();
        }
    }
}