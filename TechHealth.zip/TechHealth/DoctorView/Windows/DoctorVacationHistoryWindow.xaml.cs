﻿using System.Windows;

namespace TechHealth.DoctorView.Windows
{
    public partial class DoctorVacationHistoryWindow : Window
    {
        public DoctorVacationHistoryWindow()
        {
            InitializeComponent();
        }
    }
}