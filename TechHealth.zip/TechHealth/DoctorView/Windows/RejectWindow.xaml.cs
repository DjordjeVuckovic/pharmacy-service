﻿using System.Windows;

namespace TechHealth.DoctorView.Windows
{
    public partial class RejectWindow : Window
    {
        public RejectWindow()
        {
            InitializeComponent();
        }
    }
}