﻿using System.Windows;

namespace TechHealth.DoctorView.Windows
{
    public partial class TherapyPreview : Window
    {
        public TherapyPreview()
        {
            InitializeComponent();
        }
    }
}