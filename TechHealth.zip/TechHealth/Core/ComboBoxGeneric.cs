﻿namespace TechHealth.Core
{
    public class ComboBoxGeneric<T>
    {
        public  string DisplayText { get; set; }
        public  T Entity { get; set; }
        
    }
}