﻿namespace TechHealth.Core
{
    public interface IClosable
    {
        void Close();
    }
}