﻿namespace Scar.Common.WPF.Controls.Behaviors
{
    public enum TextBoxInputMode
    {
        None,
        DecimalInput,
        IntInput
    }
}