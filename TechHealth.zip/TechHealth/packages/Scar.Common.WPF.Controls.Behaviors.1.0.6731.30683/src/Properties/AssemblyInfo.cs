using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Scar.Common.WPF.Controls.Behaviors")]
[assembly: AssemblyCompany("Scar")]
[assembly: AssemblyProduct("Scar.Common.WPF.Controls.Behaviors")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyDescription("Various Behaviors for WPF controls")]