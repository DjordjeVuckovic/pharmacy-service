﻿using TechHealth.Model;

namespace TechHealth.Repository.IRepository
{
    public interface ISpecializationRepository:IRepository<Specialization,int>
    {
        
    }
}