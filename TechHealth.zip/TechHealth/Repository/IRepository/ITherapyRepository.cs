﻿using TechHealth.Model;

namespace TechHealth.Repository.IRepository
{
    public interface ITherapyRepository:IRepository<Therapy,string>
    {
        
    }
}