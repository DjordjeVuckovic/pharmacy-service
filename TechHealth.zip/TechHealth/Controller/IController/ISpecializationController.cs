﻿using TechHealth.Model;

namespace TechHealth.Controller.IController
{
    public interface ISpecializationController:IController<Specialization,int>
    {
        
    }
}