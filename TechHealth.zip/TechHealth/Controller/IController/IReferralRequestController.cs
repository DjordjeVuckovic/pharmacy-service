﻿using TechHealth.Model;

namespace TechHealth.Controller.IController
{
    public interface IReferralRequestController:IController<ReferralRequest,string>
    {
        
    }
}